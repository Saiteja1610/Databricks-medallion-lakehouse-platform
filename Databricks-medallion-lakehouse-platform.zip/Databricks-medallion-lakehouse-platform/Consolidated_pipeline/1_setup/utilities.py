# Databricks notebook source
bronze_schema = "bronze"
silver_schema = "silver"
gold_schema = "gold"